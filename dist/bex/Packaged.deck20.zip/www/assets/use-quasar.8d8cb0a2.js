import { z as inject, V as quasarKey } from "./index.1f497e8e.js";
function useQuasar() {
  return inject(quasarKey);
}
export { useQuasar as u };
