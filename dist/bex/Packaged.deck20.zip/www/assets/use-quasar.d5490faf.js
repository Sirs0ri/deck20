import { z as inject, V as quasarKey } from "./index.8c4d84bb.js";
function useQuasar() {
  return inject(quasarKey);
}
export { useQuasar as u };
