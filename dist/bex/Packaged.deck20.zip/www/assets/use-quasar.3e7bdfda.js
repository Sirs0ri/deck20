import { z as inject, V as quasarKey } from "./index.b0068bd8.js";
function useQuasar() {
  return inject(quasarKey);
}
export { useQuasar as u };
