import { z as inject, V as quasarKey } from "./index.e5422758.js";
function useQuasar() {
  return inject(quasarKey);
}
export { useQuasar as u };
